// src/context/AppContext.tsx
import React, { createContext, useContext, useReducer, useMemo } from 'react';
import { AppState, Task, TaskStatus, FocusSession, MainTaskOfDay } from '../types';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { v4 as uuidv4 } from 'uuid';

type Action =
  | { type: 'SET_TASKS'; payload: Task[] }
  | { type: 'ADD_TASK'; payload: Task }
  | { type: 'UPDATE_TASK_STATUS'; payload: { id: string; status: TaskStatus } }
  | { type: 'SET_MAIN_TASK_FOR_TODAY'; payload: MainTaskOfDay }
  | { type: 'ADD_FOCUS_SESSION'; payload: FocusSession }
  | { type: 'UPDATE_FOCUS_SESSION'; payload: FocusSession };

interface AppContextValue {
  state: AppState;
  addTask: (title: string, parentId?: string | null) => Task;
  updateTaskStatus: (id: string, status: TaskStatus) => void;
  setMainTaskForToday: (title: string) => void;
  getMainTaskForToday: () => MainTaskOfDay | undefined;
  addFocusSession: (session: FocusSession) => void;
  updateFocusSession: (session: FocusSession) => void;
  generateId: () => string;
}

const AppContext = createContext<AppContextValue | undefined>(undefined);

const initialState: AppState = {
  tasks: [],
  focusSessions: [],
  mainTasks: [],
};

function appReducer(state: AppState, action: Action): AppState {
  switch (action.type) {
    case 'SET_TASKS':
      return { ...state, tasks: action.payload };
    case 'ADD_TASK':
      return { ...state, tasks: [...state.tasks, action.payload] };
    case 'UPDATE_TASK_STATUS':
      return {
        ...state,
        tasks: state.tasks.map((t) =>
          t.id === action.payload.id ? { ...t, status: action.payload.status } : t
        ),
      };
    case 'SET_MAIN_TASK_FOR_TODAY':
      return {
        ...state,
        mainTasks: [
          ...state.mainTasks.filter((m) => m.date !== action.payload.date),
          action.payload,
        ],
      };
    case 'ADD_FOCUS_SESSION':
      return { ...state, focusSessions: [...state.focusSessions, action.payload] };
    case 'UPDATE_FOCUS_SESSION':
      return {
        ...state,
        focusSessions: state.focusSessions.map((s) =>
          s.id === action.payload.id ? action.payload : s
        ),
      };
    default:
      return state;
  }
}

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [persisted, setPersisted] = useLocalStorage<AppState>('ADHD_WEB_APP_STATE', initialState);
  const [state, dispatch] = useReducer(appReducer, persisted);

  // סנכרון ל-localStorage
  React.useEffect(() => {
    setPersisted(state);
  }, [state, setPersisted]);

  const generateId = () => uuidv4();

  const addTask = (title: string, parentId?: string | null): Task => {
    const id = generateId();
    const today = new Date().toISOString().slice(0, 10);
    const newTask: Task = {
      id,
      title: title.trim(),
      parentId: parentId ?? null,
      status: 'pending',
      createdAt: new Date().toISOString(),
      scheduledFor: today,
      isToday: true,
    };
    dispatch({ type: 'ADD_TASK', payload: newTask });
    return newTask;
  };

  const updateTaskStatus = (id: string, status: TaskStatus) => {
    dispatch({ type: 'UPDATE_TASK_STATUS', payload: { id, status } });
  };

  const setMainTaskForToday = (title: string) => {
    const today = new Date().toISOString().slice(0, 10);
    const main: MainTaskOfDay = { date: today, title: title.trim() };
    dispatch({ type: 'SET_MAIN_TASK_FOR_TODAY', payload: main });
  };

  const getMainTaskForToday = () => {
    const today = new Date().toISOString().slice(0, 10);
    return state.mainTasks.find((m) => m.date === today);
  };

  const addFocusSession = (session: FocusSession) => {
    dispatch({ type: 'ADD_FOCUS_SESSION', payload: session });
  };

  const updateFocusSession = (session: FocusSession) => {
    dispatch({ type: 'UPDATE_FOCUS_SESSION', payload: session });
  };

  const value: AppContextValue = useMemo(
    () => ({
      state,
      addTask,
      updateTaskStatus,
      setMainTaskForToday,
      getMainTaskForToday,
      addFocusSession,
      updateFocusSession,
      generateId,
    }),
    [state]
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};

export function useAppContext() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useAppContext must be used within AppProvider');
  return ctx;
}