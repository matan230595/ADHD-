// src/components/FocusTimer.tsx
import React, { useEffect, useRef, useState } from 'react';
import { useAppContext } from '../context/AppContext';
import { FocusSession } from '../types';

const PRESETS = [10, 15, 25]; // דקות

interface Props {
  initialTaskTitle?: string;
}

export const FocusTimer: React.FC<Props> = ({ initialTaskTitle }) => {
  const { addFocusSession, updateFocusSession, generateId } = useAppContext();
  const [selectedMinutes, setSelectedMinutes] = useState<number>(15);
  const [secondsLeft, setSecondsLeft] = useState<number>(15 * 60);
  const [running, setRunning] = useState(false);
  const [taskTitle, setTaskTitle] = useState(initialTaskTitle || 'פוקוס כללי');

  const sessionRef = useRef<FocusSession | null>(null);
  const intervalRef = useRef<number | null>(null);

  useEffect(() => {
    setSecondsLeft(selectedMinutes * 60);
  }, [selectedMinutes]);

  useEffect(() => {
    if (running) {
      const id = window.setInterval(() => {
        setSecondsLeft((prev) => {
          if (prev <= 1) {
            window.clearInterval(id);
            handleSessionEnd(false);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      intervalRef.current = id;
    } else if (intervalRef.current !== null) {
      window.clearInterval(intervalRef.current);
      intervalRef.current = null;
    }

    return () => {
      if (intervalRef.current !== null) window.clearInterval(intervalRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [running]);

  const formatTime = (totalSeconds: number) => {
    const m = Math.floor(totalSeconds / 60)
      .toString()
      .padStart(2, '0');
    const s = (totalSeconds % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  };

  const startNewSession = () => {
    const session: FocusSession = {
      id: generateId(),
      taskTitle: taskTitle || 'פוקוס כללי',
      startTime: new Date().toISOString(),
      interrupted: false,
    };
    sessionRef.current = session;
    addFocusSession(session);
  };

  const handleStart = () => {
    if (secondsLeft === 0) {
      setSecondsLeft(selectedMinutes * 60);
    }
    if (!running) {
      startNewSession();
    }
    setRunning(true);
  };

  const handlePause = () => {
    setRunning(false);
  };

  const handleReset = () => {
    setRunning(false);
    setSecondsLeft(selectedMinutes * 60);
  };

  const handleSessionEnd = (interrupted: boolean) => {
    setRunning(false);
    const session = sessionRef.current;
    if (!session) return;
    const end = new Date().toISOString();
    const start = new Date(session.startTime);
    const durationMinutes = Math.round(
      (new Date(end).getTime() - start.getTime()) / 1000 / 60
    );
    const updated: FocusSession = {
      ...session,
      endTime: end,
      durationMinutes,
      interrupted,
    };
    updateFocusSession(updated);
    sessionRef.current = null;
    if (!interrupted) {
      alert('כל הכבוד! סיימת סשן פוקוס.');
    }
  };

  const handleIAmDistracted = () => {
    handleSessionEnd(true);
    alert('הכול טוב. קורה. בוא נחזור בעדינות למשימה בצעד קטן אחד.');
  };

  return (
    <div className="card">
      <h2>מצב פוקוס</h2>
      <div style={{ marginBottom: 4 }}>המשימה שלך עכשיו:</div>
      <input
        value={taskTitle}
        onChange={(e) => setTaskTitle(e.target.value)}
        style={{
          width: '100%',
          padding: 8,
          borderRadius: 8,
          border: '1px solid #d1d5db',
          marginBottom: 12,
        }}
      />

      <div style={{ marginBottom: 8 }}>כמה זמן מרגיש אפשרי עכשיו?</div>
      <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
        {PRESETS.map((m) => (
          <button
            key={m}
            onClick={() => {
              setSelectedMinutes(m);
              setSecondsLeft(m * 60);
            }}
            style={{
              flex: 1,
              borderRadius: 999,
              padding: '6px 8px',
              border: '1px solid #4f46e5',
              backgroundColor: selectedMinutes === m ? '#4f46e5' : 'white',
              color: selectedMinutes === m ? 'white' : '#4f46e5',
            }}
          >
            {m} דקות
          </button>
        ))}
      </div>

      <div
        style={{
          textAlign: 'center',
          padding: 16,
          borderRadius: 16,
          backgroundColor: '#ffffff',
          border: '1px solid #e5e7eb',
          marginBottom: 12,
          fontSize: 32,
          fontWeight: 700,
        }}
      >
        {formatTime(secondsLeft)}
      </div>

      <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
        {!running ? (
          <button
            onClick={handleStart}
            style={{
              flex: 1,
              backgroundColor: '#22c55e',
              border: 'none',
              color: 'white',
              padding: '8px 16px',
              borderRadius: 999,
            }}
          >
            התחל
          </button>
        ) : (
          <button
            onClick={handlePause}
            style={{
              flex: 1,
              backgroundColor: '#f97316',
              border: 'none',
              color: 'white',
              padding: '8px 16px',
              borderRadius: 999,
            }}
          >
            עצור
          </button>
        )}
        <button
          onClick={handleReset}
          style={{
            flex: 1,
            backgroundColor: '#e5e7eb',
            border: 'none',
            color: '#111827',
            padding: '8px 16px',
            borderRadius: 999,
          }}
        >
          איפוס
        </button>
      </div>

      <button
        onClick={handleIAmDistracted}
        style={{
          width: '100%',
          backgroundColor: '#fee2e2',
          border: '1px solid #f97316',
          color: '#b91c1c',
          padding: '6px 12px',
          borderRadius: 8,
          fontSize: 14,
        }}
      >
        אני מוסח/ת – עזרה לחזור בעדינות
      </button>
    </div>
  );
};