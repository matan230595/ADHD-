// src/components/NavBar.tsx
import React from 'react';

interface Props {
  activeTab: 'today' | 'stats';
  onChangeTab: (tab: 'today' | 'stats') => void;
}

export const NavBar: React.FC<Props> = ({ activeTab, onChangeTab }) => {
  return (
    <nav
      style={{
        backgroundColor: '#111827',
        color: 'white',
        padding: '8px 16px',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
      }}
    >
      <div style={{ fontWeight: 600 }}>ADHD Web Focus</div>
      <div style={{ display: 'flex', gap: 8 }}>
        <button
          onClick={() => onChangeTab('today')}
          style={{
            backgroundColor: activeTab === 'today' ? '#4f46e5' : 'transparent',
            color: 'white',
            borderRadius: 999,
            border: '1px solid #4f46e5',
            padding: '4px 12px',
          }}
        >
          היום
        </button>
        <button
          onClick={() => onChangeTab('stats')}
          style={{
            backgroundColor: activeTab === 'stats' ? '#4f46e5' : 'transparent',
            color: 'white',
            borderRadius: 999,
            border: '1px solid #4f46e5',
            padding: '4px 12px',
          }}
        >
          סטטיסטיקות
        </button>
      </div>
    </nav>
  );
};