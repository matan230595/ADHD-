// src/components/StatsPanel.tsx
import React, { useMemo } from 'react';
import { useAppContext } from '../context/AppContext';
import { formatDurationMinutes, formatDate } from '../utils/time';

export const StatsPanel: React.FC = () => {
  const { state } = useAppContext();

  const stats = useMemo(() => {
    const totalSessions = state.focusSessions.length;
    const completedSessions = state.focusSessions.filter((s) => !s.interrupted && s.endTime);
    const interruptedSessions = state.focusSessions.filter((s) => s.interrupted);

    const totalMinutes = completedSessions.reduce(
      (sum, s) => sum + (s.durationMinutes || 0),
      0
    );

    const lastSessions = [...state.focusSessions]
      .sort((a, b) => (a.startTime > b.startTime ? -1 : 1))
      .slice(0, 5);

    return {
      totalSessions,
      completedSessions: completedSessions.length,
      interruptedSessions: interruptedSessions.length,
      totalMinutes,
      lastSessions,
    };
  }, [state.focusSessions]);

  return (
    <div className="card">
      <h2>סטטיסטיקות פוקוס</h2>
      <div style={{ marginBottom: 8 }}>
        <div>סה"כ סשנים: {stats.totalSessions}</div>
        <div>סשנים שהושלמו: {stats.completedSessions}</div>
        <div>סשנים שנקטעו: {stats.interruptedSessions}</div>
        <div>זמן פוקוס מצטבר: {formatDurationMinutes(stats.totalMinutes)}</div>
      </div>

      <h3>סשנים אחרונים</h3>
      {stats.lastSessions.length === 0 ? (
        <div style={{ color: '#6b7280' }}>עוד אין סשני פוקוס.</div>
      ) : (
        <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
          {stats.lastSessions.map((s) => (
            <li
              key={s.id}
              style={{
                padding: '6px 0',
                borderBottom: '1px solid #e5e7eb',
                fontSize: 14,
              }}
            >
              <div>
                <strong>{s.taskTitle || 'פוקוס כללי'}</strong>
              </div>
              <div style={{ color: '#6b7280' }}>
                {s.startTime && (
                  <>מתאריך {formatDate(s.startTime)} </>
                )}
                {s.durationMinutes && (
                  <>– {s.durationMinutes} דקות</>
                )}
                {s.interrupted && <> (נקטע)</>}
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};