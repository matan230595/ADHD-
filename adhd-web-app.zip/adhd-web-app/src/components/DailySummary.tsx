// src/components/DailySummary.tsx
import React from 'react';
import { useAppContext } from '../context/AppContext';

export const DailySummary: React.FC = () => {
  const { state } = useAppContext();
  const today = new Date().toISOString().slice(0, 10);
  const tasksToday = state.tasks.filter((t) => t.scheduledFor === today);
  const doneToday = tasksToday.filter((t) => t.status === 'done');

  return (
    <div className="card">
      <h3>סיכום היום הקצר</h3>
      <div>
        <strong>בוצע:</strong> {doneToday.length} מתוך {tasksToday.length} משימות.
      </div>
      <div style={{ marginTop: 8 }}>
        גם אם לא סיימת הכול – כל צעד קטן נחשב. מחר אפשר לנסות צעד אחד שונה.
      </div>
    </div>
  );
};