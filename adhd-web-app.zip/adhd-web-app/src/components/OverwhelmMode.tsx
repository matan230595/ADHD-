// src/components/OverwhelmMode.tsx
import React, { useState } from 'react';
import { useAppContext } from '../context/AppContext';

interface Props {
  onStartTinyFocus: (taskTitle: string, minutes: number) => void;
}

export const OverwhelmMode: React.FC<Props> = ({ onStartTinyFocus }) => {
  const { addTask } = useAppContext();
  const [visible, setVisible] = useState(false);

  const handleClick = () => setVisible((v) => !v);

  const handleOption = (type: 'open' | 'oneSentence' | 'fiveMinutes') => {
    if (type === 'open') {
      const t = addTask('רק לפתוח את מה שצריך (קובץ/אפליקציה) למשימה הבאה');
      onStartTinyFocus(t.title, 3);
    } else if (type === 'oneSentence') {
      const t = addTask('לכתוב רק משפט אחד ולהפסיק אם קשה');
      onStartTinyFocus(t.title, 5);
    } else if (type === 'fiveMinutes') {
      const t = addTask('לעבוד 5 דקות בלבד ואז להחליט מחדש');
      onStartTinyFocus(t.title, 5);
    }
    setVisible(false);
  };

  return (
    <div className="card">
      <button
        onClick={handleClick}
        style={{
          width: '100%',
          backgroundColor: '#0ea5e9',
          border: 'none',
          color: 'white',
          padding: '8px 16px',
          borderRadius: 999,
        }}
      >
        אני מרגיש/ה מוצף/ת
      </button>

      {visible && (
        <div style={{ marginTop: 12 }}>
          <div style={{ marginBottom: 8 }}>
            בואי/בוא נעשה משהו ממש קטן שאתה כן יכול/ה עכשיו:
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            <button
              onClick={() => handleOption('open')}
              style={{
                backgroundColor: '#e0f2fe',
                borderRadius: 8,
                border: '1px solid #93c5fd',
                padding: '6px 8px',
                textAlign: 'right',
              }}
            >
              רק לפתוח את מה שצריך (קובץ / אתר / מסמך)
            </button>
            <button
              onClick={() => handleOption('oneSentence')}
              style={{
                backgroundColor: '#e0f2fe',
                borderRadius: 8,
                border: '1px solid #93c5fd',
                padding: '6px 8px',
                textAlign: 'right',
              }}
            >
              לכתוב רק משפט אחד ואז מותר להפסיק
            </button>
            <button
              onClick={() => handleOption('fiveMinutes')}
              style={{
                backgroundColor: '#e0f2fe',
                borderRadius: 8,
                border: '1px solid #93c5fd',
                padding: '6px 8px',
                textAlign: 'right',
              }}
            >
              לעבוד 5 דקות ואז להחליט אם להמשיך
            </button>
          </div>
        </div>
      )}
    </div>
  );
};