// src/components/TaskList.tsx
import React, { useMemo, useState } from 'react';
import { useAppContext } from '../context/AppContext';
import { Task } from '../types';
import { TaskItem } from './TaskItem';

interface Props {
  onFocusTask: (taskTitle: string) => void;
  mainTaskTitle?: string;
}

const getAutoSteps = (mainTaskTitle: string): string[] => [
  `לפתוח את מה שצריך בשביל "${mainTaskTitle}" (קובץ / דפדפן / מסמך)`,
  `לרשום נקודות / ראשי פרקים עבור "${mainTaskTitle}"`,
  `לבצע את החלק הראשון הכי קטן של "${mainTaskTitle}"`,
  `הפסקה קצרה (5 דק')`,
  `להמשיך לעוד חלק קטן של "${mainTaskTitle}"`,
];

export const TaskList: React.FC<Props> = ({ onFocusTask, mainTaskTitle }) => {
  const { state, addTask, updateTaskStatus } = useAppContext();
  const [customStep, setCustomStep] = useState('');

  const todayTasks = useMemo(
    () => state.tasks.filter((t) => t.isToday),
    [state.tasks]
  );

  const handleToggleStatus = (task: Task) => {
    const newStatus = task.status === 'done' ? 'pending' : 'done';
    updateTaskStatus(task.id, newStatus);
  };

  const handleFocus = (task: Task) => {
    onFocusTask(task.title);
  };

  const handleAddCustom = () => {
    if (!customStep.trim()) return;
    addTask(customStep.trim(), 'MAIN');
    setCustomStep('');
  };

  const handleAutoBreakdown = () => {
    if (!mainTaskTitle) return;
    const steps = getAutoSteps(mainTaskTitle);
    steps.forEach((title) => addTask(title, 'MAIN'));
  };

  return (
    <div className="card">
      <h2>משימות היום</h2>
      {mainTaskTitle && (
        <div style={{ marginBottom: 12 }}>
          <strong>המשימה המרכזית:</strong> {mainTaskTitle}
        </div>
      )}

      <div style={{ marginBottom: 12, display: 'flex', gap: 8 }}>
        <button
          onClick={handleAutoBreakdown}
          style={{
            backgroundColor: '#4f46e5',
            border: 'none',
            color: 'white',
            padding: '6px 12px',
            borderRadius: 999,
          }}
        >
          יצירת פירוק אוטומטי
        </button>
      </div>

      <div style={{ marginBottom: 12 }}>
        <div style={{ marginBottom: 4 }}>להוסיף צעד ידני:</div>
        <div style={{ display: 'flex', gap: 8 }}>
          <input
            value={customStep}
            onChange={(e) => setCustomStep(e.target.value)}
            placeholder="מה הצעד הקטן הבא?"
            style={{
              flex: 1,
              padding: 8,
              borderRadius: 8,
              border: '1px solid #d1d5db',
            }}
          />
          <button
            onClick={handleAddCustom}
            style={{
              backgroundColor: '#10b981',
              border: 'none',
              color: 'white',
              padding: '6px 12px',
              borderRadius: 999,
            }}
          >
            הוסף
          </button>
        </div>
      </div>

      {todayTasks.length === 0 ? (
        <div style={{ color: '#6b7280' }}>
          אין משימות להיום. הגדר משימה מרכזית ופרק אותה לצעדים קטנים.
        </div>
      ) : (
        <div>
          {todayTasks.map((task) => (
            <TaskItem
              key={task.id}
              task={task}
              onToggleStatus={handleToggleStatus}
              onFocus={handleFocus}
            />
          ))}
        </div>
      )}
    </div>
  );
};