// src/components/TaskItem.tsx
import React from 'react';
import { Task } from '../types';

interface Props {
  task: Task;
  onToggleStatus: (task: Task) => void;
  onFocus: (task: Task) => void;
}

export const TaskItem: React.FC<Props> = ({ task, onToggleStatus, onFocus }) => {
  const isDone = task.status === 'done';

  return (
    <div
      style={{
        padding: 8,
        borderRadius: 8,
        backgroundColor: isDone ? '#dcfce7' : '#ffffff',
        border: '1px solid #e5e7eb',
        marginBottom: 8,
      }}
    >
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          gap: 8,
        }}
      >
        <div
          style={{
            textDecoration: isDone ? 'line-through' : 'none',
            color: isDone ? '#6b7280' : '#111827',
            flex: 1,
          }}
        >
          {task.title}
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button
            onClick={() => onToggleStatus(task)}
            style={{
              borderRadius: 999,
              border: '1px solid #9ca3af',
              background: 'white',
              padding: '4px 8px',
              fontSize: 12,
            }}
          >
            {isDone ? 'להחזיר למשימה' : 'סמן כבוצע'}
          </button>
          <button
            onClick={() => onFocus(task)}
            style={{
              borderRadius: 999,
              border: '1px solid #f97316',
              background: '#fff7ed',
              color: '#c2410c',
              padding: '4px 8px',
              fontSize: 12,
            }}
          >
            פוקוס
          </button>
        </div>
      </div>
    </div>
  );
};