// src/components/MainTaskInput.tsx
import React, { useState, useEffect } from 'react';
import { useAppContext } from '../context/AppContext';

interface Props {
  onBreakdown: (mainTaskTitle: string) => void;
}

export const MainTaskInput: React.FC<Props> = ({ onBreakdown }) => {
  const { getMainTaskForToday, setMainTaskForToday } = useAppContext();
  const [mainTask, setMainTask] = useState('');

  useEffect(() => {
    const existing = getMainTaskForToday();
    if (existing?.title) setMainTask(existing.title);
  }, [getMainTaskForToday]);

  const handleSave = () => {
    if (!mainTask.trim()) return;
    setMainTaskForToday(mainTask.trim());
    onBreakdown(mainTask.trim());
  };

  return (
    <div className="card">
      <h2>מה הדבר היחיד שהכי חשוב שיקרה היום?</h2>
      <textarea
        value={mainTask}
        onChange={(e) => setMainTask(e.target.value)}
        placeholder='לדוגמה: "לסיים דו"ח עבודה..."'
        style={{
          width: '100%',
          minHeight: 60,
          borderRadius: 8,
          padding: 8,
          border: '1px solid #d1d5db',
          resize: 'vertical',
        }}
      />
      <div style={{ marginTop: 8, display: 'flex', gap: 8 }}>
        <button
          onClick={handleSave}
          style={{
            backgroundColor: '#4f46e5',
            border: 'none',
            color: 'white',
            padding: '8px 16px',
            borderRadius: 999,
          }}
        >
          שמור ופרק למשימות קטנות
        </button>
      </div>
    </div>
  );
};