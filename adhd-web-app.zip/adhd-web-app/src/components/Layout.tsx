// src/components/Layout.tsx
import React from 'react';
import './Layout.css'; // אפשר להעלות לסגנונות הכלליים או להשאיר ריק

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return <div className="app-root">{children}</div>;
};